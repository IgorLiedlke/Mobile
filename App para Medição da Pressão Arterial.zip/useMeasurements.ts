import { useState, useEffect, useCallback } from "react";

export interface Measurement {
  id: string;
  systolic: number;
  diastolic: number;
  pulse: number;
  date: string; // ISO string
  notes?: string;
}

export type BPCategory =
  | "low"
  | "normal"
  | "elevated"
  | "stage1"
  | "stage2"
  | "crisis";

export interface BPClassification {
  category: BPCategory;
  label: string;
  description: string;
  color: string;
  badgeClass: string;
}

export function classifyBP(systolic: number, diastolic: number): BPClassification {
  if (systolic > 180 || diastolic > 120) {
    return {
      category: "crisis",
      label: "Crise Hipertensiva",
      description: "Procure atendimento médico imediatamente",
      color: "#ff4444",
      badgeClass: "badge-crisis",
    };
  }
  if (systolic >= 140 || diastolic >= 90) {
    return {
      category: "stage2",
      label: "Hipertensão Estágio 2",
      description: "Consulte um médico",
      color: "#ef4444",
      badgeClass: "badge-stage2",
    };
  }
  if ((systolic >= 130 && systolic < 140) || (diastolic >= 80 && diastolic < 90 && systolic >= 120)) {
    return {
      category: "stage1",
      label: "Hipertensão Estágio 1",
      description: "Atenção: pressão elevada",
      color: "#f97316",
      badgeClass: "badge-stage1",
    };
  }
  if (systolic >= 120 && systolic < 130 && diastolic < 80) {
    return {
      category: "elevated",
      label: "Pressão Elevada",
      description: "Acima do ideal, monitore com atenção",
      color: "#eab308",
      badgeClass: "badge-elevated",
    };
  }
  if (systolic < 90 || diastolic < 60) {
    return {
      category: "low",
      label: "Pressão Baixa",
      description: "Hipotensão, consulte um médico",
      color: "#00d4ff",
      badgeClass: "badge-low",
    };
  }
  return {
    category: "normal",
    label: "Normal",
    description: "Pressão arterial saudável",
    color: "#22c55e",
    badgeClass: "badge-normal",
  };
}

const STORAGE_KEY = "bp_measurements";

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

export function useMeasurements() {
  const [measurements, setMeasurements] = useState<Measurement[]>([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setMeasurements(JSON.parse(stored));
      }
    } catch {
      setMeasurements([]);
    }
  }, []);

  const save = useCallback((data: Measurement[]) => {
    setMeasurements(data);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, []);

  const addMeasurement = useCallback(
    (input: Omit<Measurement, "id">) => {
      const newEntry: Measurement = { ...input, id: generateId() };
      const updated = [newEntry, ...measurements];
      save(updated);
      return newEntry;
    },
    [measurements, save]
  );

  const deleteMeasurement = useCallback(
    (id: string) => {
      const updated = measurements.filter((m) => m.id !== id);
      save(updated);
    },
    [measurements, save]
  );

  const clearAll = useCallback(() => {
    save([]);
  }, [save]);

  const latestMeasurement = measurements[0] ?? null;

  const stats = (() => {
    if (measurements.length === 0) return null;
    const sys = measurements.map((m) => m.systolic);
    const dia = measurements.map((m) => m.diastolic);
    const pul = measurements.map((m) => m.pulse);
    return {
      avgSystolic: Math.round(sys.reduce((a, b) => a + b, 0) / sys.length),
      avgDiastolic: Math.round(dia.reduce((a, b) => a + b, 0) / dia.length),
      avgPulse: Math.round(pul.reduce((a, b) => a + b, 0) / pul.length),
      maxSystolic: Math.max(...sys),
      minSystolic: Math.min(...sys),
      maxDiastolic: Math.max(...dia),
      minDiastolic: Math.min(...dia),
      total: measurements.length,
    };
  })();

  return {
    measurements,
    latestMeasurement,
    stats,
    addMeasurement,
    deleteMeasurement,
    clearAll,
  };
}
