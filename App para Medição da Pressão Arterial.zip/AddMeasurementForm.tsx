/**
 * AddMeasurementForm — Formulário para registrar nova medição
 * Design: Dashboard Médico Dark Premium
 */
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import type { Measurement } from "@/hooks/useMeasurements";
import { classifyBP } from "@/hooks/useMeasurements";
import { Heart, Activity, Clock, StickyNote, Plus } from "lucide-react";

interface AddMeasurementFormProps {
  onAdd: (data: Omit<Measurement, "id">) => void;
  onClose?: () => void;
}

export default function AddMeasurementForm({ onAdd, onClose }: AddMeasurementFormProps) {
  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [pulse, setPulse] = useState("");
  const [notes, setNotes] = useState("");
  const [dateStr, setDateStr] = useState(() => {
    const now = new Date();
    return now.toISOString().slice(0, 16);
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    const sys = Number(systolic);
    const dia = Number(diastolic);
    const pul = Number(pulse);

    if (!systolic || isNaN(sys) || sys < 50 || sys > 300)
      errs.systolic = "Valor entre 50 e 300 mmHg";
    if (!diastolic || isNaN(dia) || dia < 30 || dia > 200)
      errs.diastolic = "Valor entre 30 e 200 mmHg";
    if (!pulse || isNaN(pul) || pul < 20 || pul > 300)
      errs.pulse = "Valor entre 20 e 300 bpm";
    if (sys && dia && sys <= dia)
      errs.diastolic = "Diastólica deve ser menor que sistólica";

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const sys = Number(systolic);
    const dia = Number(diastolic);
    const classification = classifyBP(sys, dia);

    onAdd({
      systolic: sys,
      diastolic: Number(diastolic),
      pulse: Number(pulse),
      date: new Date(dateStr).toISOString(),
      notes: notes.trim() || undefined,
    });

    toast.success("Medição registrada!", {
      description: `${sys}/${diastolic} mmHg — ${classification.label}`,
    });

    setSystolic("");
    setDiastolic("");
    setPulse("");
    setNotes("");
    setErrors({});
    onClose?.();
  };

  const preview = systolic && diastolic && !isNaN(Number(systolic)) && !isNaN(Number(diastolic))
    ? classifyBP(Number(systolic), Number(diastolic))
    : null;

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Preview badge */}
      {preview && (
        <div
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${preview.badgeClass}`}
        >
          <span className="w-2 h-2 rounded-full" style={{ background: preview.color }} />
          {preview.label} — {preview.description}
        </div>
      )}

      {/* Systolic & Diastolic */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5" />
            Sistólica (mmHg)
          </Label>
          <Input
            type="number"
            placeholder="120"
            value={systolic}
            onChange={(e) => setSystolic(e.target.value)}
            className="bg-background/50 border-border/50 text-foreground text-lg font-display h-12 focus:border-primary/50"
            min={50}
            max={300}
          />
          {errors.systolic && (
            <p className="text-xs text-destructive">{errors.systolic}</p>
          )}
        </div>
        <div className="space-y-2">
          <Label className="text-muted-foreground text-xs uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5" />
            Diastólica (mmHg)
          </Label>
          <Input
            type="number"
            placeholder="80"
            value={diastolic}
            onChange={(e) => setDiastolic(e.target.value)}
            className="bg-background/50 border-border/50 text-foreground text-lg font-display h-12 focus:border-primary/50"
            min={30}
            max={200}
          />
          {errors.diastolic && (
            <p className="text-xs text-destructive">{errors.diastolic}</p>
          )}
        </div>
      </div>

      {/* Pulse */}
      <div className="space-y-2">
        <Label className="text-muted-foreground text-xs uppercase tracking-wider flex items-center gap-1.5">
          <Heart className="w-3.5 h-3.5" />
          Pulso (bpm)
        </Label>
        <Input
          type="number"
          placeholder="72"
          value={pulse}
          onChange={(e) => setPulse(e.target.value)}
          className="bg-background/50 border-border/50 text-foreground text-lg font-display h-12 focus:border-primary/50"
          min={20}
          max={300}
        />
        {errors.pulse && (
          <p className="text-xs text-destructive">{errors.pulse}</p>
        )}
      </div>

      {/* Date/Time */}
      <div className="space-y-2">
        <Label className="text-muted-foreground text-xs uppercase tracking-wider flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5" />
          Data e Hora
        </Label>
        <Input
          type="datetime-local"
          value={dateStr}
          onChange={(e) => setDateStr(e.target.value)}
          className="bg-background/50 border-border/50 text-foreground h-12 focus:border-primary/50"
        />
      </div>

      {/* Notes */}
      <div className="space-y-2">
        <Label className="text-muted-foreground text-xs uppercase tracking-wider flex items-center gap-1.5">
          <StickyNote className="w-3.5 h-3.5" />
          Observações (opcional)
        </Label>
        <Textarea
          placeholder="Ex: após exercício, em repouso, tomou medicamento..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="bg-background/50 border-border/50 text-foreground resize-none focus:border-primary/50"
          rows={2}
        />
      </div>

      <Button
        type="submit"
        className="w-full h-12 text-base font-semibold gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
      >
        <Plus className="w-5 h-5" />
        Registrar Medição
      </Button>
    </form>
  );
}
