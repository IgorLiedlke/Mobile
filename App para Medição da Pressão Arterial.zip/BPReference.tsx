/**
 * BPReference — Tabela de referência de classificação da pressão arterial
 * Baseada nas diretrizes da Sociedade Brasileira de Cardiologia
 */
export default function BPReference() {
  const categories = [
    {
      label: "Hipotensão",
      systolic: "< 90",
      diastolic: "< 60",
      color: "#00d4ff",
      badgeClass: "badge-low",
      description: "Pressão baixa",
    },
    {
      label: "Normal",
      systolic: "< 120",
      diastolic: "< 80",
      color: "#22c55e",
      badgeClass: "badge-normal",
      description: "Saudável",
    },
    {
      label: "Pressão Elevada",
      systolic: "120–129",
      diastolic: "< 80",
      color: "#eab308",
      badgeClass: "badge-elevated",
      description: "Atenção",
    },
    {
      label: "Hipertensão Estágio 1",
      systolic: "130–139",
      diastolic: "80–89",
      color: "#f97316",
      badgeClass: "badge-stage1",
      description: "Consulte médico",
    },
    {
      label: "Hipertensão Estágio 2",
      systolic: "≥ 140",
      diastolic: "≥ 90",
      color: "#ef4444",
      badgeClass: "badge-stage2",
      description: "Tratamento necessário",
    },
    {
      label: "Crise Hipertensiva",
      systolic: "> 180",
      diastolic: "> 120",
      color: "#ff4444",
      badgeClass: "badge-crisis",
      description: "Emergência médica",
    },
  ];

  return (
    <div className="space-y-2">
      <p className="text-muted-foreground text-xs mb-3">
        Baseado nas diretrizes da{" "}
        <span className="text-primary/80">Sociedade Brasileira de Cardiologia (2020)</span>
      </p>
      {categories.map((cat) => (
        <div
          key={cat.label}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-muted/10 border border-border/30 hover:border-border/60 transition-colors"
        >
          <div
            className="w-2 h-2 rounded-full flex-shrink-0"
            style={{ background: cat.color, boxShadow: `0 0 6px ${cat.color}60` }}
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-medium text-foreground">{cat.label}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${cat.badgeClass}`}>
                {cat.description}
              </span>
            </div>
          </div>
          <div className="text-right flex-shrink-0">
            <div className="text-xs text-muted-foreground">
              <span className="text-foreground/70 font-mono">{cat.systolic}</span>
              <span className="mx-1">/</span>
              <span className="text-foreground/70 font-mono">{cat.diastolic}</span>
              <span className="ml-1 text-muted-foreground/50">mmHg</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
