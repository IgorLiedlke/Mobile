/**
 * BPStats — Cards de estatísticas resumidas
 * Design: Dashboard Médico Dark Premium
 */
import type { Measurement } from "@/hooks/useMeasurements";
import { classifyBP } from "@/hooks/useMeasurements";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

interface BPStatsProps {
  measurements: Measurement[];
}

function StatCard({
  label,
  value,
  unit,
  sub,
  color,
  trend,
}: {
  label: string;
  value: number | string;
  unit?: string;
  sub?: string;
  color?: string;
  trend?: "up" | "down" | "stable";
}) {
  const TrendIcon =
    trend === "up" ? TrendingUp : trend === "down" ? TrendingDown : Minus;
  const trendColor =
    trend === "up"
      ? "text-red-400"
      : trend === "down"
      ? "text-green-400"
      : "text-muted-foreground";

  return (
    <div className="card-glow rounded-xl p-4">
      <p className="text-muted-foreground text-xs uppercase tracking-wider mb-2">{label}</p>
      <div className="flex items-end gap-1.5">
        <span
          className="font-display text-3xl leading-none"
          style={{ color: color || "inherit" }}
        >
          {value}
        </span>
        {unit && (
          <span className="text-muted-foreground text-xs mb-0.5">{unit}</span>
        )}
        {trend && (
          <TrendIcon className={`w-4 h-4 mb-0.5 ml-auto ${trendColor}`} />
        )}
      </div>
      {sub && <p className="text-muted-foreground/60 text-xs mt-1">{sub}</p>}
    </div>
  );
}

export default function BPStats({ measurements }: BPStatsProps) {
  if (measurements.length === 0) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {["Sistólica Média", "Diastólica Média", "Pulso Médio", "Total de Medições"].map((label) => (
          <div key={label} className="card-glow rounded-xl p-4">
            <p className="text-muted-foreground text-xs uppercase tracking-wider mb-2">{label}</p>
            <div className="h-8 bg-muted/20 rounded animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  const sys = measurements.map((m) => m.systolic);
  const dia = measurements.map((m) => m.diastolic);
  const pul = measurements.map((m) => m.pulse);

  const avgSys = Math.round(sys.reduce((a, b) => a + b, 0) / sys.length);
  const avgDia = Math.round(dia.reduce((a, b) => a + b, 0) / dia.length);
  const avgPul = Math.round(pul.reduce((a, b) => a + b, 0) / pul.length);

  const avgClassification = classifyBP(avgSys, avgDia);

  // Trend: compare last 3 vs previous 3
  let sysTrend: "up" | "down" | "stable" = "stable";
  if (measurements.length >= 6) {
    const recent = measurements.slice(0, 3).reduce((a, b) => a + b.systolic, 0) / 3;
    const older = measurements.slice(3, 6).reduce((a, b) => a + b.systolic, 0) / 3;
    if (recent > older + 3) sysTrend = "up";
    else if (recent < older - 3) sysTrend = "down";
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          label="Sistólica Média"
          value={avgSys}
          unit="mmHg"
          sub={`Máx: ${Math.max(...sys)} / Mín: ${Math.min(...sys)}`}
          color="#00d4ff"
          trend={sysTrend}
        />
        <StatCard
          label="Diastólica Média"
          value={avgDia}
          unit="mmHg"
          sub={`Máx: ${Math.max(...dia)} / Mín: ${Math.min(...dia)}`}
          color="#22c55e"
        />
        <StatCard
          label="Pulso Médio"
          value={avgPul}
          unit="bpm"
          sub={`Máx: ${Math.max(...pul)} / Mín: ${Math.min(...pul)}`}
          color="#f97316"
        />
        <StatCard
          label="Total de Medições"
          value={measurements.length}
          sub={`Classificação média: ${avgClassification.label}`}
          color={avgClassification.color}
        />
      </div>
    </div>
  );
}
