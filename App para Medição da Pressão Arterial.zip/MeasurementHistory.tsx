/**
 * MeasurementHistory — Tabela de histórico de medições
 * Design: Dashboard Médico Dark Premium
 */
import { useState } from "react";
import { Trash2, ChevronDown, ChevronUp, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Measurement } from "@/hooks/useMeasurements";
import { classifyBP } from "@/hooks/useMeasurements";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface MeasurementHistoryProps {
  measurements: Measurement[];
  onDelete: (id: string) => void;
}

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function MeasurementHistory({ measurements, onDelete }: MeasurementHistoryProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (measurements.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-muted/30 flex items-center justify-center mb-4">
          <span className="text-3xl opacity-40">📋</span>
        </div>
        <p className="text-muted-foreground text-sm">Nenhuma medição registrada ainda.</p>
        <p className="text-muted-foreground/60 text-xs mt-1">
          Adicione sua primeira medição para começar o acompanhamento.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {measurements.map((m, index) => {
        const cls = classifyBP(m.systolic, m.diastolic);
        const isExpanded = expandedId === m.id;
        const isLatest = index === 0;

        return (
          <div
            key={m.id}
            className={`card-glow rounded-xl overflow-hidden transition-all duration-200 ${
              isLatest ? "border-primary/20" : ""
            }`}
          >
            <div
              className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-white/[0.02]"
              onClick={() => setExpandedId(isExpanded ? null : m.id)}
            >
              {/* Status dot */}
              <div
                className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                style={{ background: cls.color, boxShadow: `0 0 8px ${cls.color}60` }}
              />

              {/* BP values */}
              <div className="flex items-baseline gap-1 min-w-[100px]">
                <span className="font-display text-xl text-foreground">{m.systolic}</span>
                <span className="text-muted-foreground text-sm">/</span>
                <span className="font-display text-xl text-foreground">{m.diastolic}</span>
                <span className="text-muted-foreground text-xs ml-0.5">mmHg</span>
              </div>

              {/* Pulse */}
              <div className="flex items-center gap-1 text-muted-foreground text-sm min-w-[60px]">
                <span className="text-xs">♥</span>
                <span className="font-medium">{m.pulse}</span>
                <span className="text-xs">bpm</span>
              </div>

              {/* Badge */}
              <span className={`text-xs px-2 py-0.5 rounded-full hidden sm:inline-flex ${cls.badgeClass}`}>
                {cls.label}
              </span>

              {/* Date */}
              <span className="text-muted-foreground text-xs ml-auto hidden md:block">
                {formatDate(m.date)}
              </span>

              {/* Latest badge */}
              {isLatest && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20 hidden sm:block">
                  Última
                </span>
              )}

              {/* Notes indicator */}
              {m.notes && (
                <StickyNote className="w-3.5 h-3.5 text-muted-foreground/50 flex-shrink-0" />
              )}

              {/* Expand toggle */}
              <button className="text-muted-foreground/50 hover:text-muted-foreground flex-shrink-0">
                {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>

            {/* Expanded details */}
            {isExpanded && (
              <div className="px-4 pb-4 pt-1 border-t border-border/50 space-y-3 animate-fade-in-up">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Data e Hora</p>
                    <p className="text-foreground">{formatDate(m.date)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Classificação</p>
                    <p style={{ color: cls.color }}>{cls.label}</p>
                    <p className="text-muted-foreground text-xs">{cls.description}</p>
                  </div>
                </div>

                {m.notes && (
                  <div>
                    <p className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Observações</p>
                    <p className="text-foreground text-sm bg-muted/20 rounded-lg px-3 py-2">{m.notes}</p>
                  </div>
                )}

                <div className="flex justify-end">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive/70 hover:text-destructive hover:bg-destructive/10 gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Excluir
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-border">
                      <AlertDialogHeader>
                        <AlertDialogTitle>Excluir medição?</AlertDialogTitle>
                        <AlertDialogDescription className="text-muted-foreground">
                          Esta ação não pode ser desfeita. A medição de {m.systolic}/{m.diastolic} mmHg
                          registrada em {formatDate(m.date)} será removida permanentemente.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="bg-muted/30 border-border">Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(m.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Excluir
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
