/**
 * BPGauge — Gauge semicircular SVG animado
 * Design: Dashboard Médico Dark Premium
 * Gradiente verde→amarelo→vermelho conforme nível de pressão
 */
import { useEffect, useState } from "react";
import { classifyBP } from "@/hooks/useMeasurements";

interface BPGaugeProps {
  systolic: number;
  diastolic: number;
  animate?: boolean;
}

export default function BPGauge({ systolic, diastolic, animate = true }: BPGaugeProps) {
  const [displayed, setDisplayed] = useState(animate ? 0 : systolic);
  const classification = classifyBP(systolic, diastolic);

  useEffect(() => {
    if (!animate) {
      setDisplayed(systolic);
      return;
    }
    let start = 0;
    const end = systolic;
    const duration = 800;
    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(start + (end - start) * eased));
      if (progress < 1) requestAnimationFrame(step);
    };

    requestAnimationFrame(step);
  }, [systolic, animate]);

  // Gauge parameters
  const cx = 120;
  const cy = 115;
  const r = 88;
  const startAngle = -210; // degrees from 3 o'clock
  const endAngle = 30;
  const totalAngle = endAngle - startAngle; // 240 degrees

  // Map systolic (60–200) to angle
  const minVal = 60;
  const maxVal = 200;
  const clampedVal = Math.max(minVal, Math.min(maxVal, displayed));
  const fraction = (clampedVal - minVal) / (maxVal - minVal);
  const needleAngle = startAngle + fraction * totalAngle;

  function polarToCartesian(cx: number, cy: number, r: number, angleDeg: number) {
    const rad = ((angleDeg - 90) * Math.PI) / 180;
    return {
      x: cx + r * Math.cos(rad),
      y: cy + r * Math.sin(rad),
    };
  }

  function arcPath(cx: number, cy: number, r: number, startDeg: number, endDeg: number) {
    const start = polarToCartesian(cx, cy, r, endDeg);
    const end = polarToCartesian(cx, cy, r, startDeg);
    const largeArc = endDeg - startDeg <= 180 ? "0" : "1";
    return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 0 ${end.x} ${end.y}`;
  }

  // Needle tip
  const needleTip = polarToCartesian(cx, cy, r - 10, needleAngle);
  const needleBase1 = polarToCartesian(cx, cy, 10, needleAngle + 90);
  const needleBase2 = polarToCartesian(cx, cy, 10, needleAngle - 90);

  // Color segments
  const segments = [
    { from: startAngle, to: startAngle + totalAngle * 0.25, color: "#22c55e" },  // normal
    { from: startAngle + totalAngle * 0.25, to: startAngle + totalAngle * 0.45, color: "#84cc16" }, // elevated
    { from: startAngle + totalAngle * 0.45, to: startAngle + totalAngle * 0.60, color: "#eab308" }, // stage1
    { from: startAngle + totalAngle * 0.60, to: startAngle + totalAngle * 0.75, color: "#f97316" }, // stage2
    { from: startAngle + totalAngle * 0.75, to: endAngle, color: "#ef4444" },    // crisis
  ];

  return (
    <div className="flex flex-col items-center">
      <svg width="240" height="170" viewBox="0 0 240 170">
        <defs>
          <filter id="glow-needle">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <filter id="glow-arc">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Background track */}
        <path
          d={arcPath(cx, cy, r, startAngle, endAngle)}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth="12"
          strokeLinecap="round"
        />

        {/* Color segments */}
        {segments.map((seg, i) => (
          <path
            key={i}
            d={arcPath(cx, cy, r, seg.from, seg.to)}
            fill="none"
            stroke={seg.color}
            strokeWidth="10"
            strokeLinecap="round"
            opacity="0.7"
            filter="url(#glow-arc)"
          />
        ))}

        {/* Needle */}
        <polygon
          points={`${needleTip.x},${needleTip.y} ${needleBase1.x},${needleBase1.y} ${needleBase2.x},${needleBase2.y}`}
          fill="white"
          opacity="0.9"
          filter="url(#glow-needle)"
          style={{ transition: animate ? "all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)" : "none" }}
        />

        {/* Center circle */}
        <circle cx={cx} cy={cy} r="8" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />
        <circle cx={cx} cy={cy} r="4" fill="white" opacity="0.8" />

        {/* Tick marks */}
        {[0, 0.25, 0.5, 0.75, 1].map((frac) => {
          const angle = startAngle + frac * totalAngle;
          const inner = polarToCartesian(cx, cy, r - 18, angle);
          const outer = polarToCartesian(cx, cy, r + 2, angle);
          return (
            <line
              key={frac}
              x1={inner.x} y1={inner.y}
              x2={outer.x} y2={outer.y}
              stroke="rgba(255,255,255,0.25)"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          );
        })}

        {/* Labels */}
        {[
          { val: "60", frac: 0 },
          { val: "100", frac: 0.31 },
          { val: "140", frac: 0.63 },
          { val: "200", frac: 1 },
        ].map(({ val, frac }) => {
          const angle = startAngle + frac * totalAngle;
          const pos = polarToCartesian(cx, cy, r - 28, angle);
          return (
            <text
              key={val}
              x={pos.x}
              y={pos.y}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="rgba(255,255,255,0.35)"
              fontSize="9"
              fontFamily="Space Grotesk, sans-serif"
            >
              {val}
            </text>
          );
        })}
      </svg>

      {/* Value display */}
      <div className="flex items-end gap-2 -mt-4">
        <span
          className="font-display text-5xl leading-none"
          style={{ color: classification.color }}
        >
          {displayed}
        </span>
        <span className="text-muted-foreground text-sm mb-1 font-medium">
          / {diastolic} <span className="text-xs">mmHg</span>
        </span>
      </div>
      <div className="mt-2">
        <span className={`text-xs font-medium px-3 py-1 rounded-full ${classification.badgeClass}`}>
          {classification.label}
        </span>
      </div>
    </div>
  );
}
