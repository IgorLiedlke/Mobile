/**
 * BPChart — Gráfico de evolução da pressão arterial
 * Design: Dashboard Médico Dark Premium
 * Usa Recharts com tema escuro
 */
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import type { Measurement } from "@/hooks/useMeasurements";

interface BPChartProps {
  measurements: Measurement[];
}

function formatShortDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border/50 rounded-xl px-4 py-3 shadow-xl text-sm">
        <p className="text-muted-foreground text-xs mb-2">{label}</p>
        {payload.map((p: any) => (
          <div key={p.dataKey} className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
            <span className="text-muted-foreground capitalize">
              {p.dataKey === "systolic" ? "Sistólica" : p.dataKey === "diastolic" ? "Diastólica" : "Pulso"}:
            </span>
            <span className="font-display font-semibold text-foreground">
              {p.value}
              <span className="text-xs text-muted-foreground ml-1">
                {p.dataKey === "pulse" ? "bpm" : "mmHg"}
              </span>
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function BPChart({ measurements }: BPChartProps) {
  if (measurements.length < 2) {
    return (
      <div className="flex flex-col items-center justify-center h-48 text-center">
        <div className="text-4xl opacity-30 mb-3">📈</div>
        <p className="text-muted-foreground text-sm">
          Adicione pelo menos 2 medições para ver o gráfico de evolução.
        </p>
      </div>
    );
  }

  // Reverse to show chronological order
  const data = [...measurements]
    .reverse()
    .slice(-20) // last 20 measurements
    .map((m) => ({
      date: formatShortDate(m.date),
      systolic: m.systolic,
      diastolic: m.diastolic,
      pulse: m.pulse,
    }));

  return (
    <div className="w-full">
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgba(255,255,255,0.05)"
            vertical={false}
          />
          <XAxis
            dataKey="date"
            tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Inter" }}
            axisLine={{ stroke: "rgba(255,255,255,0.08)" }}
            tickLine={false}
          />
          <YAxis
            domain={[40, 200]}
            tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Inter" }}
            axisLine={false}
            tickLine={false}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            wrapperStyle={{ fontSize: "12px", color: "rgba(255,255,255,0.5)", fontFamily: "Inter" }}
            formatter={(value) =>
              value === "systolic" ? "Sistólica" : value === "diastolic" ? "Diastólica" : "Pulso"
            }
          />

          {/* Reference lines for normal range */}
          <ReferenceLine
            y={120}
            stroke="rgba(234,179,8,0.2)"
            strokeDasharray="4 4"
            label={{ value: "120", fill: "rgba(234,179,8,0.4)", fontSize: 10, position: "right" }}
          />
          <ReferenceLine
            y={80}
            stroke="rgba(234,179,8,0.2)"
            strokeDasharray="4 4"
            label={{ value: "80", fill: "rgba(234,179,8,0.4)", fontSize: 10, position: "right" }}
          />

          <Line
            type="monotone"
            dataKey="systolic"
            stroke="#00d4ff"
            strokeWidth={2.5}
            dot={{ fill: "#00d4ff", r: 4, strokeWidth: 0 }}
            activeDot={{ r: 6, fill: "#00d4ff", stroke: "rgba(0,212,255,0.3)", strokeWidth: 4 }}
          />
          <Line
            type="monotone"
            dataKey="diastolic"
            stroke="#22c55e"
            strokeWidth={2.5}
            dot={{ fill: "#22c55e", r: 4, strokeWidth: 0 }}
            activeDot={{ r: 6, fill: "#22c55e", stroke: "rgba(34,197,94,0.3)", strokeWidth: 4 }}
          />
          <Line
            type="monotone"
            dataKey="pulse"
            stroke="#f97316"
            strokeWidth={1.5}
            strokeDasharray="5 3"
            dot={{ fill: "#f97316", r: 3, strokeWidth: 0 }}
            activeDot={{ r: 5, fill: "#f97316" }}
          />
        </LineChart>
      </ResponsiveContainer>

      <p className="text-muted-foreground/50 text-xs text-center mt-2">
        Linhas tracejadas indicam os limites da pressão normal (120/80 mmHg)
      </p>
    </div>
  );
}
