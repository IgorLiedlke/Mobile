/**
 * Home — Página principal do Monitor de Pressão Arterial
 * Design: Dashboard Médico Dark Premium
 * Fontes: Space Grotesk (títulos/números) + Inter (corpo/labels)
 * Cores: Fundo #0F1117, acentos ciano (#00d4ff) e verde (#22c55e)
 */
import { useState } from "react";
import { useMeasurements, classifyBP } from "@/hooks/useMeasurements";
import BPGauge from "@/components/BPGauge";
import AddMeasurementForm from "@/components/AddMeasurementForm";
import MeasurementHistory from "@/components/MeasurementHistory";
import BPChart from "@/components/BPChart";
import BPStats from "@/components/BPStats";
import BPReference from "@/components/BPReference";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Activity, BarChart3, Clock, BookOpen, Trash2, Download } from "lucide-react";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426347478/doRUEtxwcAU3UPTCo2zgqS/hero-heart-monitor-2nTpgA8PEfPKbkWJ9iAknj.webp";
const HEART_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663426347478/doRUEtxwcAU3UPTCo2zgqS/heart-icon-glow-NjmZTYEtJMB7RYs53WwLV9.webp";

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function Home() {
  const { measurements, latestMeasurement, addMeasurement, deleteMeasurement, clearAll } =
    useMeasurements();
  const [dialogOpen, setDialogOpen] = useState(false);

  const exportCSV = () => {
    if (measurements.length === 0) return;
    const header = "Data,Sistólica (mmHg),Diastólica (mmHg),Pulso (bpm),Classificação,Observações";
    const rows = measurements.map((m) => {
      const cls = classifyBP(m.systolic, m.diastolic);
      const date = new Date(m.date).toLocaleString("pt-BR");
      return `"${date}",${m.systolic},${m.diastolic},${m.pulse},"${cls.label}","${m.notes || ""}"`;
    });
    const csv = [header, ...rows].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pressao-arterial-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* ── Header ── */}
      <header className="border-b border-border/40 bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container flex items-center justify-between h-14">
          <div className="flex items-center gap-2.5">
            <img
              src={HEART_IMG}
              alt="Monitor de Pressão"
              className="w-8 h-8 rounded-lg object-cover"
            />
            <div>
              <h1 className="font-display text-sm font-semibold text-foreground leading-none">
                Monitor de Pressão
              </h1>
              <p className="text-muted-foreground text-xs">Pressão Arterial</p>
            </div>
          </div>

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5 h-8 text-xs font-semibold">
                <Plus className="w-3.5 h-3.5" />
                Nova Medição
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="font-display">Registrar Medição</DialogTitle>
              </DialogHeader>
              <AddMeasurementForm
                onAdd={addMeasurement}
                onClose={() => setDialogOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <main className="container py-6 space-y-6">
        {/* ── Hero Section ── */}
        <section
          className="relative rounded-2xl overflow-hidden min-h-[220px] flex items-center"
          style={{
            background: `linear-gradient(135deg, rgba(15,17,23,0.95) 0%, rgba(15,17,23,0.80) 50%, rgba(0,30,50,0.85) 100%)`,
          }}
        >
          {/* Background image */}
          <div
            className="absolute inset-0 bg-cover bg-center opacity-20"
            style={{ backgroundImage: `url(${HERO_IMG})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-transparent" />

          <div className="relative z-10 flex flex-col lg:flex-row items-center gap-8 w-full px-6 py-8">
            {/* Left: text info */}
            <div className="flex-1 text-center lg:text-left">
              <p className="text-primary text-xs font-semibold uppercase tracking-widest mb-2">
                Monitoramento Contínuo
              </p>
              <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground leading-tight mb-3">
                Sua Pressão Arterial
                <br />
                <span className="text-primary">em Tempo Real</span>
              </h2>
              <p className="text-muted-foreground text-sm max-w-sm">
                Registre, acompanhe e analise suas medições com classificação automática
                baseada nas diretrizes da Sociedade Brasileira de Cardiologia.
              </p>

              {latestMeasurement && (
                <div className="mt-4 flex items-center gap-2 justify-center lg:justify-start">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-muted-foreground text-xs">
                    Última medição: {formatDate(latestMeasurement.date)}
                  </span>
                </div>
              )}

              {!latestMeasurement && (
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="mt-4 gap-2" size="sm">
                      <Plus className="w-4 h-4" />
                      Registrar Primeira Medição
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-card border-border sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="font-display">Registrar Medição</DialogTitle>
                    </DialogHeader>
                    <AddMeasurementForm
                      onAdd={addMeasurement}
                      onClose={() => setDialogOpen(false)}
                    />
                  </DialogContent>
                </Dialog>
              )}
            </div>

            {/* Right: Gauge */}
            <div className="flex-shrink-0">
              {latestMeasurement ? (
                <BPGauge
                  systolic={latestMeasurement.systolic}
                  diastolic={latestMeasurement.diastolic}
                  animate
                />
              ) : (
                <div className="flex flex-col items-center">
                  <div className="opacity-30">
                    <BPGauge systolic={115} diastolic={75} animate={false} />
                  </div>
                  <p className="text-muted-foreground/50 text-xs -mt-2">Exemplo de leitura</p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ── Stats ── */}
        {measurements.length > 0 && (
          <section>
            <BPStats measurements={measurements} />
          </section>
        )}

        {/* ── Main Tabs ── */}
        <section>
          <Tabs defaultValue="history" className="w-full">
            <div className="flex items-center justify-between mb-4">
              <TabsList className="bg-card border border-border/50 h-9">
                <TabsTrigger value="history" className="gap-1.5 text-xs h-7">
                  <Clock className="w-3.5 h-3.5" />
                  Histórico
                </TabsTrigger>
                <TabsTrigger value="chart" className="gap-1.5 text-xs h-7">
                  <BarChart3 className="w-3.5 h-3.5" />
                  Gráfico
                </TabsTrigger>
                <TabsTrigger value="reference" className="gap-1.5 text-xs h-7">
                  <BookOpen className="w-3.5 h-3.5" />
                  Referência
                </TabsTrigger>
              </TabsList>

              {measurements.length > 0 && (
                <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={exportCSV}
                  className="text-muted-foreground hover:text-primary hover:bg-primary/10 gap-1.5 text-xs h-8"
                >
                  <Download className="w-3.5 h-3.5" />
                  Exportar CSV
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 gap-1.5 text-xs h-8"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Limpar Tudo
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-card border-border">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Limpar todo o histórico?</AlertDialogTitle>
                      <AlertDialogDescription className="text-muted-foreground">
                        Esta ação irá remover permanentemente todas as {measurements.length} medições
                        registradas. Esta ação não pode ser desfeita.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-muted/30 border-border">Cancelar</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={clearAll}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Limpar Tudo
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                </div>
              )}
            </div>

            {/* History tab */}
            <TabsContent value="history" className="mt-0">
              <div className="card-glow rounded-xl p-4">
                <div className="flex items-center gap-2 mb-4">
                  <Activity className="w-4 h-4 text-primary" />
                  <h3 className="font-display font-semibold text-sm">
                    Histórico de Medições
                  </h3>
                  {measurements.length > 0 && (
                    <span className="ml-auto text-xs text-muted-foreground">
                      {measurements.length} registro{measurements.length !== 1 ? "s" : ""}
                    </span>
                  )}
                </div>
                <MeasurementHistory
                  measurements={measurements}
                  onDelete={deleteMeasurement}
                />
              </div>
            </TabsContent>

            {/* Chart tab */}
            <TabsContent value="chart" className="mt-0">
              <div className="card-glow rounded-xl p-4">
                <div className="flex items-center gap-2 mb-4">
                  <BarChart3 className="w-4 h-4 text-primary" />
                  <h3 className="font-display font-semibold text-sm">
                    Evolução da Pressão Arterial
                  </h3>
                  {measurements.length > 0 && (
                    <span className="ml-auto text-xs text-muted-foreground">
                      Últimas {Math.min(measurements.length, 20)} medições
                    </span>
                  )}
                </div>
                <BPChart measurements={measurements} />
              </div>
            </TabsContent>

            {/* Reference tab */}
            <TabsContent value="reference" className="mt-0">
              <div className="card-glow rounded-xl p-4">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen className="w-4 h-4 text-primary" />
                  <h3 className="font-display font-semibold text-sm">
                    Tabela de Classificação
                  </h3>
                </div>
                <BPReference />
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* ── Footer ── */}
        <footer className="text-center py-4 border-t border-border/30">
          <p className="text-muted-foreground/40 text-xs">
            Monitor de Pressão Arterial — Dados armazenados localmente no seu dispositivo.
            Este app não substitui orientação médica profissional.
          </p>
        </footer>
      </main>
    </div>
  );
}
